/* Colton Kelsey
   Program 4 Linked List Stack
 */

import java.util.EmptyStackException;
public class MyLinkedStack {

    private Node head;
    private Node tail;
    private int size;

    public MyLinkedStack() {
        this.size = 0;
    }

    public void push(char value) {
        Node node = new Node(value);
        node.next = head;
        head = node;

        if (tail == null) {
            tail = head;

        }
        size++;  // increment the size of the stack.
    }


    public char pop() {
        if (empty()) {
            throw new EmptyStackException();
        } else {
            char poppedValue = head.value;
            head = head.next;
            size--;
            return poppedValue;

        }
    }

    boolean empty() {  // returns true if empty
        return size == 0;
    }

    public int size() {
        return size + 1; // gives total count of Nodes
    }

    public char peek() {
    if(empty()){
        throw new EmptyStackException();
    } else {
        return head.value;   // returns
    }
    }


    private class Node {
        private char value;
        private Node next;

        public Node(char value) {
            this.value = value;
            this.next = next;
        }
    }
}